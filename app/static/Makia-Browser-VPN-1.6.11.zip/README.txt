Makia Browser VPN v1.6.11
Chrome: chrome://extensions → Developer mode → Load unpacked → select the extracted folder.
Edge: edge://extensions → Developer mode → Load unpacked → select the extracted folder.
Controller: https://p.mahinet.shop
Connection affects the browser only. Existing unpacked installs require manual reload.
